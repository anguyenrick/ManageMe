package com.example.manageme.Controller;

public class TrashCanController {
}
