package com.example.manageme;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.navigation.NavigationView;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

/**
 * <p>A fragment that shows a list of items as a modal bottom sheet.</p>
 * <p>You can show this modal bottom sheet from your activity like this:</p>
 * <pre>
 *     bottomDrawerNavigation.newInstance(30).show(getSupportFragmentManager(), "dialog");
 * </pre>
 */
public class bottomDrawerNavigation extends BottomSheetDialogFragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_bottom_sheet, container, false);

        NavigationView nav_view = view.findViewById(R.id.nav_bottom);

        nav_view.setNavigationItemSelectedListener(bottomListener);

        return view;

    }

    private NavigationView.OnNavigationItemSelectedListener bottomListener = new NavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

            Intent activity = null;
            switch (menuItem.getItemId()){

                case R.id.nav_group:
                    activity = new Intent(getContext(),CreateGroup.class);
                    Toast.makeText(getContext(),"Créer un groupe",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.nav_task:
                    activity = new Intent(getContext(),CreateTask.class);
                    Toast.makeText(getContext(),"Créer une tâche",Toast.LENGTH_SHORT).show();
                    break;
            }
            startActivity(activity);
            return true;
        }
    };
}