package com.example.manageme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.manageme.Model.Room;
import com.example.manageme.ui.SeeTask;
import com.example.manageme.ui.meeting;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import io.realm.mongodb.User;

public class Main extends AppCompatActivity {

    private User user;
    private Room room;
    private Task task;
    private BottomNavigationView btNavigation;
    private NavigationView sidebarNavigation;

    private Toolbar toolbar;
    private DrawerLayout sidebar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        configSidebarListener();
        configBottomListener();
        configToolBar();
        configDrawer();

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new SeeTask()).commit();

    }

    @Override
    public void onBackPressed() {
        if(sidebar.isDrawerOpen(GravityCompat.START)){
            sidebar.closeDrawer(GravityCompat.START);
        }else{
            super.onBackPressed();
        }
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navigationListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

            Fragment selectedFragment=null;

            switch (menuItem.getItemId()){
                case R.id.nav_join_room:
                    selectedFragment=new JoinRoom();
                    break;
                case R.id.nav_plus:
                    selectedFragment = new bottomDrawerNavigation();
                    break;

                case R.id.nav_meeting:
                    selectedFragment = new meeting();
                    break;

            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectedFragment).commit();
            return true;
        }
    };

    private NavigationView.OnNavigationItemSelectedListener sidebarListener = new NavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

            Intent selectedActivity = null;

            switch (menuItem.getItemId()){
                case R.id.nav_profil_sidebar:
                    selectedActivity = new Intent(getApplicationContext(),Profil.class);
                    Toast.makeText(getApplicationContext(),"Profil",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.nav_saved:

                    break;
                case R.id.nav_logout:
                    selectedActivity = new Intent(getApplicationContext(),HomeScreen.class);
                    logout();
                    break;

            }
            sidebar.closeDrawer(GravityCompat.START);
            startActivity(selectedActivity);
            return true;
        }
    };

    private void configSidebarListener(){
        sidebarNavigation = findViewById(R.id.nav_sidebar);
        sidebarNavigation.setNavigationItemSelectedListener(sidebarListener);
    }
    private void configBottomListener(){
        btNavigation = findViewById(R.id.nav_bottom);
        btNavigation.setOnNavigationItemSelectedListener(navigationListener);
    }

    private void configToolBar(){
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    private void configDrawer(){
        sidebar = findViewById(R.id.drawer_sidebar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, sidebar, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        sidebar.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void logout(){

        FirebaseAuth.getInstance().signOut();
    }
}