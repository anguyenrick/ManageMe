package com.example.manageme.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.manageme.Model.TaskF;
import com.example.manageme.R;


import java.util.ArrayList;


public class TaskAdapter extends RecyclerView.Adapter<ViewHolder> {

    Context context;
    ArrayList<TaskF>AListTask;


    public TaskAdapter(Context c,ArrayList<TaskF>lTask){
        this.context=c;
        this.AListTask=lTask;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.task_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        TaskF task=AListTask.get(position);
        getTaskDetails(holder,task);

    }

    public void getTaskDetails(ViewHolder vh,TaskF task){

        final String nameTask = task.getName();
        final String description = task.getDescription();
        final String taskId = task.getTask_id();
        final String userCreator = task.getUserCreator();


        vh.getTvManagerCreator().setText(userCreator);
        vh.getTvName().setText(nameTask);
        //vh.getTvRoom().setText(taskId+"h");
        vh.getTvDescription().setText(description);

        Spinner sp = vh.getSpOptions();
        Button btn = vh.getBtnDone();
        configSpinner(sp);
        configButton(btn);
    }

    private void configButton(Button btn){

        btn.setOnClickListener(v -> {

            Toast.makeText(context,"Terminer",Toast.LENGTH_SHORT).show();
        });
    }

    private void configSpinner(Spinner sp){

        ArrayList<String> AlistOptionsTask = new ArrayList<>();
        AlistOptionsTask.add("Saved");
        AlistOptionsTask.add("Delete");
        populateSpinner(AlistOptionsTask,sp);

    }

    private void populateSpinner(ArrayList<String>Al, Spinner sp){

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                context,
                android.R.layout.simple_list_item_1,
                Al);
        sp.setAdapter(adapter);
    }

    @Override
    public int getItemCount() {
        return AListTask.size();
    }
}
