package com.example.manageme.Model;


public class Room  {

    private int iIdRoom;
    private int iIdCreator;
    private String title;

    public Room(int creator, String groupTitle) {

        this.iIdCreator = creator;
        this.title = groupTitle;
    }

    public int getiIdRoom() {
        return iIdRoom;
    }

    public int getiIdCreator() {
        return iIdCreator;
    }

    public String getTitle() {
        return title;
    }

    public void setiIdRoom(int iIdRoom) {
        this.iIdRoom = iIdRoom;
    }

    public void setiIdCreator(int iIdCreator) {
        this.iIdCreator = iIdCreator;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
