package com.example.manageme.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.manageme.Adapter.TaskAdapter;
import com.example.manageme.Model.Firebase;
import com.example.manageme.Model.TaskF;
import com.example.manageme.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;


public class SeeTask extends Fragment {

    private RecyclerView recyclerView;
    private ArrayList<TaskF> AllUserTask;
    private Firebase firebase;
    private FirebaseFirestore firestore;
    private FirebaseAuth fbAuth;
    private String userID;

    public SeeTask() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_see_task, container, false);
        defineFirebase();
        recyclerView = view.findViewById(R.id.recyclerview_task);
        show_task();
        return view;
    }

    private void defineFirebase(){

        firebase = Firebase.getInstance();
        firestore=FirebaseFirestore.getInstance();
        fbAuth = FirebaseAuth.getInstance();
        userID = fbAuth.getCurrentUser().getUid();

    }

    private void show_task(){

        AllUserTask = new ArrayList<>();

        firebase.getAllTask(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                firestore.collection("task")
                        .whereEqualTo("userCreator", userID)
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull com.google.android.gms.tasks.Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {

                                        Log.d("GET TASK", document.getId() + " => " + ""+document.getData());

                                        TaskF t = document.toObject(TaskF.class);
                                        t.setIdTask(document.getId());
                                        AllUserTask.add(t);
                                        TaskAdapter adapter = new TaskAdapter(getContext(),AllUserTask);
                                        recyclerView.setAdapter(adapter);
                                        Log.d("TASK INFO",""+t.getUserCreator()+"/"+t.getName()+"/"+t.getDescription()+"/"+t.getCategory()+"/"+t.getPriority()+"/"+t.getStatus());

                                    }
                                } else {
                                    Log.w("GET TASK", "Error getting documents.", task.getException());
                                }
                            }});
            }
        });

    }
}