package com.example.manageme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.manageme.Adapter.TaskAdapter;
import com.example.manageme.Model.Firebase;
import com.example.manageme.Model.Manager;
import com.example.manageme.Model.TaskF;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class Profil extends AppCompatActivity {

    private EditText Edpseudo;
    private EditText Edmail;
    private EditText Edpwd;
    private Button btnUpdate;
    private Button btnDelete;
    private Firebase firebase;
    private FirebaseAuth fbAuth;
    private FirebaseUser user;
    private FirebaseFirestore firestore;
    private String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        defineFirebase();
        initView();
        configButton();
        setView();


    }

    private void setView(){

        firebase.getManager(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {

                firestore.collection("manager")
                        .whereEqualTo("userID", userID)
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull com.google.android.gms.tasks.Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {

                                        Log.d("GET MANAGER", document.getId() + " => " + ""+document.getData());

                                        Manager m = document.toObject(Manager.class);

                                        Edpseudo.setText(m.getPseudo());
                                        Edmail.setText(m.getEmail());
                                        Edpwd.setText(m.getPassword());
                                    }
                                } else {
                                    Log.w("GET MANAGER", "Error getting manager.", task.getException());
                                }
                            }});
            }
        });
    }

    private TextWatcher elementListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String email = Edmail.getText().toString();
            String pseudo = Edpseudo.getText().toString();
            String pwd = Edpwd.getText().toString();

            if(!(email.isEmpty()||pseudo.isEmpty()||pwd.isEmpty())){

                if(email.contains("@")){
                    btnDelete.setEnabled(true);
                    btnUpdate.setEnabled(true);
                    btnUpdate.setBackgroundResource(R.color.mainTheme);
                    btnDelete.setBackgroundResource(R.color.mainTheme);
                }
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    private void initView(){

        Edpseudo = findViewById(R.id.profil_ed_pseudo);
        Edmail = findViewById(R.id.profil_ed_mail);
        Edpwd = findViewById(R.id.profil_edtxt_pwd);
        btnUpdate = findViewById(R.id.profil_btn_update);
        btnDelete = findViewById(R.id.profil_btn_delete);

        Edpseudo.addTextChangedListener(elementListener);
        Edpwd.addTextChangedListener(elementListener);
        Edmail.addTextChangedListener(elementListener);

        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
        btnUpdate.setBackgroundResource(R.color.textwatcher);
        btnDelete.setBackgroundResource(R.color.textwatcher);

    }

    private void gotoMain(){

        Intent i = new Intent(getApplicationContext(),HomeScreen.class);
        startActivity(i);
    }

    private void goToLogin(){

        Intent i = new Intent(getApplicationContext(),Login.class);
        startActivity(i);
    }

    private void configButton(){

        String pseudo = Edpseudo.getText().toString().trim();
        String mail = Edmail.getText().toString().trim();
        String password = Edpwd.getText().toString().trim();

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Profil.this);
                builder.setPositiveButton(R.string.oui, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
                builder.setNegativeButton(R.string.non, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.setTitle(R.string.updateMessage);
                dialog.show();
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(Profil.this);
                builder.setPositiveButton(R.string.oui, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        firebase.getManager(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {

                                user.delete()
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    Log.d("DELETE", "User account deleted.");
                                                    gotoMain();
                                                }
                                            }
                                        });
                            }
                        });

                    }
                });
                builder.setNegativeButton(R.string.non, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.setTitle(R.string.deleteMessage);
                dialog.show();
            }
        });
    }

    private void defineFirebase(){

        firebase = Firebase.getInstance();
        fbAuth = FirebaseAuth.getInstance();
        user = fbAuth.getCurrentUser();
        userID = fbAuth.getCurrentUser().getUid();
        firestore = FirebaseFirestore.getInstance();
    }


}