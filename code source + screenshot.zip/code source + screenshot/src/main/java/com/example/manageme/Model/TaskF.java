package com.example.manageme.Model;

import org.bson.types.ObjectId;

import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

public class TaskF {


    private String idTask;

    private String date;

    private String description;

   private String  group_id;

    private String name;

    private String priority;

    private boolean category;


    private String userpseudo;


    private String userCreator;


    private boolean status;

    private String task_id;

    public TaskF(){}

    public TaskF(String userCreator,String description,String name,boolean category,String date,String priority,boolean status){

        this.userCreator=userCreator;
        this.description=description;
        this.name=name;
        this.category=category;
        this.date=date;
        this.priority=priority;
        this.status=status;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String descript) {
        this.description = descript;
    }

    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public boolean getCategory() {
        return category;
    }

    public void setCategory(boolean bpublic) {
        this.category = bpublic;
    }

    public String getUserpseudo() {
        return userpseudo;
    }

    public void setUserpseudo(String userpseudo) {
        this.userpseudo = userpseudo;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getTask_id() {
        return task_id;
    }

    public void setTask_id(String task_id) {
        this.task_id = task_id;
    }

    public String getUserCreator() {
        return userCreator;
    }

    public void setUserCreator(String user_id) {
        this.userCreator = user_id;
    }

    public String getIdTask() {
        return idTask;
    }

    public void setIdTask(String idTask) {
        this.idTask = idTask;
    }










}
