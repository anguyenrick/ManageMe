package com.example.manageme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.concurrent.atomic.AtomicReference;

import io.realm.mongodb.App;
import io.realm.mongodb.Credentials;
import io.realm.mongodb.User;
import static com.example.manageme.HomeScreen.mongodb;

public class Login extends AppCompatActivity {

    private EditText EditMail;
    private EditText EditPassword;
    private Button BtnLogIn;
    private FirebaseAuth FbAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initView();// init elements with findview
        btnConfig();// add background and disable

        FbAuth = FirebaseAuth.getInstance();
        BtnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                login();
            }
        });

    }

    private TextWatcher logInTextwatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        String sMail = EditMail.getText().toString().trim();
        String sPassword = EditPassword.getText().toString().trim();

        if(!(sMail.isEmpty() || sPassword.isEmpty())){

            if(sMail.contains("@")){
                BtnLogIn.setEnabled(true);
                BtnLogIn.setBackgroundResource(R.color.mainTheme);
            }
        }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void toSignin(View view){
        Intent i = new Intent(this,HomeScreen.class);
        startActivity(i);
    }

    public void initView(){
        EditMail = findViewById(R.id.login_editText_mail);
        EditPassword = findViewById(R.id.login_editText_pwd);
        BtnLogIn = findViewById(R.id.login_btn_login);

        EditMail.addTextChangedListener(logInTextwatcher);
        EditPassword.addTextChangedListener(logInTextwatcher);
    }

    public void btnConfig(){

        BtnLogIn.setEnabled(false);
        BtnLogIn.setBackgroundResource(R.color.textwatcher);

    }

    private void login(){

        String sMail = EditMail.getText().toString();
        String sPassword = EditPassword.getText().toString();

        FbAuth.signInWithEmailAndPassword(sMail, sPassword)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("MAIL LOGIN", "signInWithEmail:success");
                            Intent i = new Intent(getApplicationContext(),Main.class);
                            startActivity(i);
                            Toast.makeText(getApplicationContext(),"Bienvenu",Toast.LENGTH_SHORT).show();

                        } else {

                            Log.w("MAIL LOGIN", "signInWithEmail:failure", task.getException());
                            Toast.makeText(getApplicationContext(),"Déjà inscrit?",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}