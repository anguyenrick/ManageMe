package com.example.manageme.Model;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

import org.bson.types.ObjectId;
public class History extends RealmObject {
    @PrimaryKey
    private ObjectId _id;
    @Required
    private String date;
    @Required
    private ObjectId task;
    // Standard getters & setters
    public ObjectId get_id() { return _id; }
    public void set_id(ObjectId _id) { this._id = _id; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public ObjectId getTask() { return task; }
    public void setTask(ObjectId task) { this.task = task; }
}
