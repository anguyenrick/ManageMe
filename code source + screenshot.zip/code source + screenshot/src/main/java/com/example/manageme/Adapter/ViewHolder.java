package com.example.manageme.Adapter;

import android.content.Context;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.manageme.R;

import java.util.ArrayList;

public class ViewHolder extends RecyclerView.ViewHolder {

    private TextView TvManagerCreator;
    private TextView TvName;
    private TextView TvRoom;
    private TextView TvDescription;
    private Spinner SpOptions;
    private Button BtnDone;


    public ViewHolder(@NonNull View itemView) {
        super(itemView);

        initView(itemView);

    }

    private void initView(View itemv){
        TvManagerCreator = itemView.findViewById(R.id.tv_task_creator);
        TvName = itemView.findViewById(R.id.tv_task_name);
        TvRoom = itemView.findViewById(R.id.tv_task_group);
        TvDescription = itemView.findViewById(R.id.tv_task_description);
        SpOptions = itemv.findViewById(R.id.sp_task_creator);
        BtnDone = itemv.findViewById(R.id.btn_confirm_done);
    }


    public TextView getTvManagerCreator() {
        return TvManagerCreator;
    }

    public TextView getTvName() {
        return TvName;
    }

    public TextView getTvRoom() {
        return TvRoom;
    }

    public TextView getTvDescription() {
        return TvDescription;
    }

    public Spinner getSpOptions() {
        return SpOptions;
    }

    public Button getBtnDone() { return BtnDone; }

}
