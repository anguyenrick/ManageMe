package com.example.manageme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.manageme.Model.Firebase;
import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class CreateTask extends AppCompatActivity {

    private Spinner spCategory;
    private Spinner spPriority;
    private Spinner spGroup;
    private EditText EditTaskName;
    private EditText EditTaskDescript;
    private Button btnConfirm;
    private Button btnCancel;
    private ArrayList<String> AlistCategory;
    private ArrayList<String> AlistPriority;
    private ArrayList<String>AlistGroup; //group of a specific user

    //Spinner
    //private String selectedCategory;
    private boolean bpublic;
    private String selectedPriority;

    private Firebase firebase;
    private FirebaseAuth fbAuth;
    private String UserID;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_task);


        defineFirebase();
        initView();
        configButton();
        configSpinner();
    }

    private void defineFirebase(){

        firebase = Firebase.getInstance();
        fbAuth = FirebaseAuth.getInstance();
        UserID = fbAuth.getCurrentUser().getUid();
        //FirebaseUser user = fbAuth.getCurrentUser();
    }

    private void initView(){

        spCategory = findViewById(R.id.Create_task_spin_category);
        spPriority = findViewById(R.id.Create_task_spin_priority);
        spGroup = findViewById(R.id.create_task_spin_group);
        EditTaskName = findViewById(R.id.create_name_task);
        EditTaskDescript = findViewById(R.id.create_task_description);
        btnConfirm = findViewById(R.id.create_task_btn_confirm);
        btnCancel = findViewById(R.id.create_task_btn_cancel);

        EditTaskName.addTextChangedListener(elementListener);
        EditTaskDescript.addTextChangedListener(elementListener);

    }

    private TextWatcher elementListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        String taskName = EditTaskName.getText().toString().trim();
        String taskDescript = EditTaskDescript.getText().toString().trim();

        if(!(taskName.isEmpty() || taskDescript.isEmpty()))
        {
            btnConfirm.setEnabled(true);
            btnConfirm.setBackgroundResource(R.color.mainTheme);
        }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    private void configButton(){

        btnConfirm.setEnabled(false);
        btnConfirm.setBackgroundResource(R.color.textwatcher);

        btnConfirm.setOnClickListener(v -> {

            String taskName = EditTaskName.getText().toString();
            String taskDescription = EditTaskDescript.getText().toString();

            if(!(taskName.isEmpty()||taskDescription.isEmpty())){

                String date = getDate();
                boolean bStatus = false;

                firebase.insertTask(UserID,taskDescription,taskName,bpublic,date,selectedPriority,bStatus);
                goToMain();
                Toast.makeText(this,"Task saved!",Toast.LENGTH_SHORT).show();
            }else{

                Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show();
            }

        });

        btnCancel.setOnClickListener(v -> {
           goToMain();
        });
    }

    private void goToMain(){
        Intent i = new Intent(getApplicationContext(),Main.class);
        startActivity(i);
    }

    private void saveTask(String name,String description){

        /*MongoClient mongoClient = user.getMongoClient(MongoServiceName);
        MongoDatabase mongoDatabase = mongoClient.getDatabase(DatabaseName);
        MongoCollection<Document> mongoCollection  = mongoDatabase.getCollection(CollectionTask);

        String date = getDate();
        CollectionKey  userK = new CollectionKey();// récupère la clé pour raison des rôles
        Task t = new Task();
        Document Newtask = new Document(userK.getUserKey(),user.getId())
                .append(t.getDate(),date)
                .append(t.getDescript(),description)
                .append(t.getName(),name)
                .append(t.getFieldPriority(),selectedPriority)
                .append(t.getFieldPublic(),bpublic);

        mongoCollection.insertOne(Newtask).getAsync(task -> {
            if (task.isSuccess()) {
                BsonObjectId insertedId = task.get().getInsertedId().asObjectId();
                goToMain();
                Log.v("EXAMPLE", "successfully inserted a document with id " + insertedId);
            } else {
                Log.e("EXAMPLE", "failed to insert document with: ", task.getError());
            }
        });*/

    }
    private String getDate(){
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        String date = df.format(Calendar.getInstance().getTime());
        return  date;
    }

    private void configSpinner(){

        AlistCategory = new ArrayList<>();
        AlistPriority = new ArrayList<>();

        AlistCategory.add("Public");
        AlistCategory.add("Privé");

        AlistPriority.add("High");
        AlistPriority.add("Medium");
        AlistPriority.add("Low");

        populateSpinner(AlistCategory,spCategory);
        populateSpinner(AlistPriority,spPriority);


        spCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = parent.getItemAtPosition(position).toString();

                if(selectedCategory(position))bpublic=true;
                    bpublic=false;
                //Toast.makeText(getApplicationContext(),"value: "+bpublic,Toast.LENGTH_SHORT).show();
                Toast.makeText(getApplicationContext(),""+selectedCategory,Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spPriority.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedPriority = parent.getItemAtPosition(position).toString();

                Toast.makeText(getApplicationContext(),""+selectedPriority,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void populateSpinner(ArrayList<String>Al,Spinner sp){

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                Al);
        sp.setAdapter(adapter);

    }

    private boolean selectedCategory(int position){

        return (position==0);
    }
}