package com.example.manageme.Model;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Firebase {

    private static final Firebase fb = new Firebase();

    private FirebaseFirestore firestore=FirebaseFirestore.getInstance();

    private String CollectionManager="manager";
    private String CollectionTask="task";
    private String CollectionRoom="room";
    private String CollectionDelete="delete";
    private String CollectionHistory="history";


    public static final Firebase getInstance()
    {
        return fb;
    }

    public void insertUser(String userId,String pseudo,String password,String email){

        Map<String, Object> user = new HashMap<>();
        user.put("userID",userId);
        user.put("pseudo", pseudo);
        user.put("password", password);
        user.put("email", email);

        firestore.collection(CollectionManager)
                .add(user)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d("INSERT", "DocumentSnapshot added with ID: " + documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("INSERT", "Error adding document", e);
                    }
                });

    }

    public void insertTask(String userID,String description,String name,boolean category,String date,String priority,boolean status){

        Map<String, Object> task = new HashMap<>();
        task.put("userCreator", userID);
        task.put("description", description);
        task.put("name",name);
        task.put("category", category);
        task.put("date",date);
        task.put("priority",priority);
        task.put("status",status);

        firestore.collection(CollectionTask)
                .add(task)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d("INSERT", "DocumentSnapshot added with ID: " + documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("INSERT", "Error adding document", e);
                    }
                });


    }

    public void getAllTask(OnCompleteListener<QuerySnapshot>listener){

        firestore.collection(CollectionTask).get().addOnCompleteListener(listener);
    }

   public void getManager(OnCompleteListener<QuerySnapshot>listener){

        firestore.collection(CollectionManager).get().addOnCompleteListener(listener);
   }

    public String getCollectionTask() {
        return CollectionTask;
    }

    public String getCollectionManager() {
        return CollectionManager;
    }

    public String getCollectionHistory() {
        return CollectionHistory;
    }

    public String getCollectionDelete() {
        return CollectionDelete;
    }

    public String getCollectionRoom() {
        return CollectionRoom;
    }

    public FirebaseFirestore getFirestore() {
        return firestore;
    }

}
