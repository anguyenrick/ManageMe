package com.example.manageme;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.material.navigation.NavigationView;

public class sidebarNavigation extends Fragment {


    private  NavigationView navigationView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fragment_sidebar_navigation, container, false);

        navigationView = view.findViewById(R.id.nav_sidebar);

        navigationView.setNavigationItemSelectedListener(sidebarListener);

        return view;
    }

    private NavigationView.OnNavigationItemSelectedListener sidebarListener = new NavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

            Intent selectedActivity = null;

            switch (menuItem.getItemId()){
                case R.id.nav_profil_sidebar:
                    selectedActivity = new Intent(getContext(),Profil.class);
                    Toast.makeText(getContext(),"Profil",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.nav_logout:
                    selectedActivity = new Intent(getContext(),HomeScreen.class);
                    break;

            }
            //sidebar.closeDrawer(GravityCompat.START);
            startActivity(selectedActivity);
            return true;
        }
    };
}