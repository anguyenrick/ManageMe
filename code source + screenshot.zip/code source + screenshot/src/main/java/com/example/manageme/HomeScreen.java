package com.example.manageme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.manageme.Model.Firebase;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import io.realm.Realm;


public class HomeScreen extends AppCompatActivity {
    public static Database mongodb;

    private EditText Editmail;
    private EditText EditPseudo;
    private EditText EditPassword;
    private Button BtnSubmit;
    public static Firebase firebase;
    private FirebaseAuth FbAuth;
    private String UserID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_screen);
        Realm.init(this);

        FbAuth = FirebaseAuth.getInstance();
        defineFiretore();
        initView();
        BtnSubmit = findViewById(R.id.homeScreen_btn_sign);
        BtnSubmit.setEnabled(false);
        BtnSubmit.setBackgroundResource(R.color.textwatcher);

        BtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                insert();
            }
        });

    }

    private TextWatcher signInTextwatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        String sPseudo = EditPseudo.getText().toString().trim();
        String sPassword= EditPassword.getText().toString().trim();
        String sEmail = Editmail.getText().toString().trim();

        if(!(sPseudo.isEmpty() || sPassword.isEmpty() || sEmail.isEmpty())){

            if(sEmail.contains("@")){
                BtnSubmit.setEnabled(true);
                BtnSubmit.setBackgroundResource(R.color.mainTheme);
            }
        }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void toLogin(View view){
        Intent i = new Intent(this, Login.class);
        startActivity(i);
    }

    public void initView(){

        Editmail = findViewById(R.id.homescreen_editText_mail);
        EditPseudo = findViewById(R.id.homescreen_editText_pseudo);
        EditPassword= findViewById(R.id.homescreen_editText_password);

        Editmail.addTextChangedListener(signInTextwatcher);
        EditPseudo.addTextChangedListener(signInTextwatcher);
        EditPassword.addTextChangedListener(signInTextwatcher);

    }

    public void insert(){
        String mail=Editmail.getText().toString().trim();
        String pwd =EditPassword.getText().toString().trim();
        String pseudo=EditPseudo.getText().toString().trim();

        FbAuth.createUserWithEmailAndPassword(mail, pwd)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            UserID = FbAuth.getCurrentUser().getUid();
                            firebase.insertUser(UserID,pseudo,pwd,mail);
                            Log.d("MAIL SUCCESS", "createUserWithEmail:success");
                            Intent i = new Intent(getApplicationContext(),Main.class);
                            startActivity(i);
                        } else {
                            Log.e("Fail","Fail to register");
                            Toast.makeText(getApplicationContext(),"Erreur database",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    public void defineAppId(){


          /*app.getEmailPassword().registerUserAsync(mail,pwd, it -> {
                    if (it.isSuccess()) {
                        Log.i("register","Successfully registered user.");
                        Intent i = new Intent(getApplicationContext(),Main.class);
                        startActivity(i);
                    } else {
                        Log.e("register","Failed to register user:"+it.getError());
                        Toast.makeText(getApplicationContext(),"fail",Toast.LENGTH_SHORT).show();
                    }
                });*/
    }

    public void defineFiretore(){

        firebase = Firebase.getInstance();
    }
}