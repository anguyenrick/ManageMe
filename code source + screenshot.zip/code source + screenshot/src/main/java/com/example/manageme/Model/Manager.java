package com.example.manageme.Model;


public class Manager {

    private String userId;
    private String pseudo;
    private String email;
    private String password;

    public Manager(){
        //
    }

    public Manager(String pseudo,String mail,String password){

        this.pseudo=pseudo;
        this.email=mail;
        this.password=password;
    }

    public String getPseudo() {
        return pseudo;
    }

    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String mail) {
        this.email = mail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


}
