package com.example.manageme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

public class CreateGroup extends AppCompatActivity {

    private EditText EditName;
    private EditText EditDescription;
    private Button BtnConfirm;
    private Button BtnCancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_group);

        initView();
        configButton();

    }

    private void initView(){

        EditName = findViewById(R.id.create_group_title);
        EditDescription = findViewById(R.id.create_group_description);

        EditName.addTextChangedListener(editListener);
        EditDescription.addTextChangedListener(editListener);
    }

    private void configButton(){

        BtnConfirm = findViewById(R.id.create_group_btn_confirm);
        BtnCancel = findViewById(R.id.create_task_btn_cancel);

        BtnConfirm.setEnabled(false);
        BtnConfirm.setBackgroundResource(R.color.mainTheme);

        BtnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        BtnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Main.class);
                startActivity(i);
            }
        });

    }

    private TextWatcher editListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };
}